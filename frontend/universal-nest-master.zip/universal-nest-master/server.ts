import 'zone.js/dist/zone-node';
import './server/main';
export * from './src/main.server';
