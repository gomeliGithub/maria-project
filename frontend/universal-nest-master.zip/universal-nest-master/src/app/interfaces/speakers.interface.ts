export interface Speaker {
  name: string;
  talk: string;
  image: string;
}
