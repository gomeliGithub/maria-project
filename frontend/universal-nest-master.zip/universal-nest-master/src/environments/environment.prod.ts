export const environment = {
  production: true,
  prerenderUrl: 'http://localhost:4000'
};
